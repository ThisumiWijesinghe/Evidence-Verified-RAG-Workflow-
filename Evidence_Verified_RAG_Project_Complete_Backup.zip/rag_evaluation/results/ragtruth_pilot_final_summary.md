# RAGTruth Exploratory Pilot Evaluation

## Experimental Setup
- Dataset: RAGTruth official test split
- Responses: 20
- Evaluation: Response-level hallucination detection
- Verification units: Sentences
- Prediction rule: Any unsupported or contradicted sentence

## Performance
- Accuracy: 70.00%
- Precision: 70.00%
- Recall: 70.00%
- F1-score: 70.00%

## Confusion Matrix
- True negatives: 7
- False positives: 3
- False negatives: 3
- True positives: 7

## Task-Level Accuracy
- QA: 70.00% (10 responses)
- Summary: 70.00% (10 responses)

## Gold Span Analysis
- Inspected annotated spans: 4
- Successfully aligned: 4
- Aligned spans in sentences marked SUPPORTED: 4

## Observed Failure Categories
- Response 11905: NONFACTUAL_ABSTENTION — An uncertainty statement was treated as an unsupported factual claim.
- Response 11906: NONFACTUAL_ABSTENTION — A refusal to answer was incorrectly flagged as hallucination.
- Response 11907: MIXED_NONFACTUAL_AND_EVIDENCE_HANDLING — Introductory text, uncertainty statements, and evidence interpretation require separate review.
- Response 28: ENTITY_ATTRIBUTION_AND_TEMPORAL_INFERENCE — Incorrect attribution and unsupported arrest timing were accepted.
- Response 29: TEMPORAL_INFERENCE — Ticket purchase date was incorrectly treated as an arrest date.
- Response 46: NUMERICAL_INCONSISTENCY — Five infections were confused with three deaths.

## Limitations
- Small, deliberately balanced exploratory sample.
- Sentence verification units are not always atomic claims.
- Nonfactual statements may generate false positives.
- Verifier labels may contradict their own explanations.
- Gold character spans are not equivalent to sentence labels.
- The pilot does not measure end-to-end RAG generation quality.
- The inspected test examples must not be reused as an unbiased final test after tuning.
